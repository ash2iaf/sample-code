﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.ProjectServer.Client;
using Microsoft.SharePoint.Client;
using Wictor.Office365;

namespace EPM.Migration.Utility.WithConfiguration
{
    public partial class ProjectBackupForm : System.Windows.Forms.Form
    {
        public string OnLinePWAURL, OnPrimePWAURL;
        //public LoginForm loginForm;
        public CustomFieldsMigrationForm cfMigurationForm;
        public ProjectContext projContext, projOnLineContext;

        public List<CFDetails> cfDetailList = new List<CFDetails>();
        public List<ProjectInfo> projInfoList = new List<ProjectInfo>();

        public string ProjectName;
        public int timeoutSeconds = 15;
        public string ProjectDataPath;

        public ProjectBackupForm()
        {
            InitializeComponent();
        }

        private void ProjectBackupForm_Load(object sender, EventArgs e)
        {
            //OnPrimePWAURL = ((LoginForm)loginForm).OnPrimePWAURL;
            //OnLinePWAURL = ((LoginForm)loginForm).OnLinePWAURL;
            //projContext = ((LoginForm)loginForm).projContext;
            //projOnLineContext = ((LoginForm)loginForm).projOnLineContext;
            btnBackup.Enabled = false;
            OnPrimePWAURL = ((CustomFieldsMigrationForm)cfMigurationForm).OnPrimePWAURL;
            OnLinePWAURL = ((CustomFieldsMigrationForm)cfMigurationForm).OnLinePWAURL;
            projContext = ((CustomFieldsMigrationForm)cfMigurationForm).projContext;
            projOnLineContext = ((CustomFieldsMigrationForm)cfMigurationForm).projOnLineContext;
            cfDetailList = ((CustomFieldsMigrationForm)cfMigurationForm).cfDetailList;
            GetAllProjects();
            GenerateDynamicControlFirstTime();
            btnNext.Enabled = false;
        }


        private void btnBackup_Click(object sender, EventArgs e)
        {

            List<ProjectNameList> ProjectNameList_Obj = new List<ProjectNameList>();
            for (int i = 0; i < chk_ProjectName.Items.Count; i++)
            {
                if (chk_ProjectName.GetItemChecked(i))
                {
                    ProjectNameList_Obj.Add(new ProjectNameList
                    {
                        ProjectName = chk_ProjectName.Items[i].ToString()
                    });
                }
            }


            #region OldCode
            //ProjectCreationInformation newProj;
            //PublishedProject newPublishedProj;
            //QueueJob qJob;
            //JobState jobState;            
            //foreach (PublishedProject onPrimPubProj in projContext.Projects)
            //{
            //    newProj = new ProjectCreationInformation();
            //    newProj.Id = onPrimPubProj.Id;// Guid.NewGuid();
            //    newProj.Name = ProjectName = onPrimPubProj.Name;// "Test Project with CSOM";
            //    newProj.Description = onPrimPubProj.Description;// "Test creating a project with CSOM";
            //    newProj.Start = onPrimPubProj.StartDate;// DateTime.Today.Date;
            //    newPublishedProj = projOnLineContext.Projects.Add(newProj);
            //    qJob = projOnLineContext.Projects.Update();

            //    jobState = projOnLineContext.WaitForQueue(qJob, timeoutSeconds);
            //    projOnLineContext.WaitForQueue(qJob, timeoutSeconds);
            //    if (jobState == JobState.Success)
            //    {
            //        //projCreated = true;

            //        var projectColl = projOnLineContext.LoadQuery(projOnLineContext.Projects.Where(p => p.Name == ProjectName));
            //        projOnLineContext.ExecuteQuery();
            //        PublishedProject onLinePubProj = projectColl.First();

            //        //UpdateProjectCustomFields(onPrimPubProj, onLinePubProj);
            //        CreateWBS(onPrimPubProj, onLinePubProj);

            //    }//end IF jobState
            //}
            #endregion

            btnBackup.Enabled = false;
            BackupProgressBar.Minimum = 0;
            BackupProgressBar.Maximum = 100;
            BackupProgressBar.Value = 1;
            BackupProgressBar.Step = 1;
            //string ProjectDataPath = @"C:\Users\epmadmin\Documents\Visual Studio 2012\Projects\EPM.Migration.Utility.WithConfiguration\EPM.Migration.Utility.WithConfiguration\bin\Debug\ProjectData";
            ProjectDataPath = Path.Combine(Environment.CurrentDirectory, "ProjectData");
            Directory.CreateDirectory(ProjectDataPath);
            BackupRestoreProjects.BackupMPPsFromPWA(projContext, OnPrimePWAURL, false, "", "", ProjectDataPath, BackupProgressBar, ProjectNameList_Obj);
            GetCFData();
            BackupProgressBar.Value = 100; //count no. of projects + buffertime
            btnNext.Enabled = true;
            MessageBox.Show("Projects backup process completed. Click next to restore projects.");
        }//end btnBackup_Click

        private void GetCFData()
        {
            if (cfDetailList != null && cfDetailList.Count > 0)
            {
                ProjectInfo projInfo;
                List<ProjectCFData> ProjCFDataList = new List<ProjectCFData>();
                ProjectCFData ProjCFData;
                List<TaskCFData> TaskCFDataList = new List<TaskCFData>();
                TaskCFData TskCFData;
                foreach (PublishedProject onPrimPubProj in projContext.Projects)
                {
                    projInfo = new ProjectInfo();
                    ProjCFDataList = new List<ProjectCFData>();
                    TaskCFDataList = new List<TaskCFData>();
                    projInfo.ProjectUID = onPrimPubProj.Id;
                    projInfo.ProjectName = onPrimPubProj.Name;
                    foreach (var CFValue in onPrimPubProj.IncludeCustomFields.FieldValues)
                    {
                        if (cfDetailList.Exists(x => x.CustomFieldOldKeyName == CFValue.Key))
                        {
                            ProjCFData = new ProjectCFData();
                            ProjCFData.ProjectCustomFieldKeyName = cfDetailList.Find(x => x.CustomFieldOldKeyName == CFValue.Key).CustomFieldNewKeyName;// CFValue.Key;
                            ProjCFData.ProjectCustomFieldValue = CFValue.Value.ToString();
                            ProjCFDataList.Add(ProjCFData);
                        }
                    }
                    foreach (var pubTask in onPrimPubProj.Tasks)
                    {
                        projContext.LoadQuery(pubTask.CustomFields);
                        projContext.ExecuteQuery();
                        var values = pubTask.FieldValues;
                        foreach (var item in values)
                        {
                            if (cfDetailList.Exists(x => x.CustomFieldOldKeyName == item.Key))
                            {
                                TskCFData = new TaskCFData();
                                TskCFData.TaskID = pubTask.Id.ToString();
                                TskCFData.OutlineLevel = pubTask.OutlineLevel.ToString();
                                TskCFData.OutlinePosition = pubTask.OutlinePosition;
                                TskCFData.TaskCustomFieldKeyName = cfDetailList.Find(x => x.CustomFieldOldKeyName == item.Key).CustomFieldNewKeyName;// item.Key;
                                TskCFData.TaskCustomFieldValue = item.Value.ToString();
                                TaskCFDataList.Add(TskCFData);
                            }
                        }
                    }
                    projInfo.ProjCFData = ProjCFDataList;
                    projInfo.TaskCFData = TaskCFDataList;
                    projInfoList.Add(projInfo);
                }
            }//End of IF
        }

        private void UpdateProjectCustomFields(PublishedProject onPrimPubProj, PublishedProject onLinePubProj)
        {
            foreach (var item in onPrimPubProj.IncludeCustomFields.FieldValues)
            {

            }

            if (!onLinePubProj.IsCheckedOut)
            {
                DraftProject projCheckedOut = onLinePubProj.CheckOut();
                //projCheckedOut.Description = "This content updated by ProjectServerCode";
                projCheckedOut.SetCustomFieldValue("Custom_75b64e74-6a01-e611-80d4-00155d18750a", "Check sync3");
                projCheckedOut.Update();
                projOnLineContext.Load(projCheckedOut);
                projOnLineContext.ExecuteQuery();
                projOnLineContext.Projects.Update();
                projOnLineContext.ExecuteQuery();
                projCheckedOut.Publish(true);
                JobState jobState1 = projOnLineContext.WaitForQueue(projOnLineContext.Projects.Update(), timeoutSeconds);
            }
        }

        private void CreateWBS(PublishedProject onPrimPubProj, PublishedProject onLinePubProj)
        {
            TaskCreationInformation newTask;
            DraftProject projCheckedOut = onLinePubProj.CheckOut();
            foreach (var item in onPrimPubProj.Tasks)
            {
                newTask = new TaskCreationInformation();
                newTask.Id = item.Id;
                newTask.Name = item.Name;
                newTask.IsManual = item.IsManual;
                newTask.Start = item.Start;
                newTask.Finish = item.Finish;
                newTask.Duration = item.Duration;
                newTask.Notes = item.Notes;

                projCheckedOut.Tasks.Add(newTask);
            }
            QueueJob qJob = projCheckedOut.Update();
            projCheckedOut.Publish(true);
            qJob = projOnLineContext.Projects.Update();
            JobState jobState = projOnLineContext.WaitForQueue(qJob, timeoutSeconds);

            if (jobState == JobState.Success)
            {
                var projectColl = projOnLineContext.LoadQuery(projOnLineContext.Projects.Where(p => p.Name == ProjectName));
                projOnLineContext.ExecuteQuery();
                onLinePubProj = projectColl.First();
                if (!onLinePubProj.IsCheckedOut)
                {
                    projCheckedOut = onLinePubProj.CheckOut();
                }
                projOnLineContext.Load(projCheckedOut.Tasks);
                projOnLineContext.ExecuteQuery();
                DraftTaskCollection getTask = projCheckedOut.Tasks;
                foreach (DraftTask task in getTask)
                { }
                foreach (var item in onPrimPubProj.Tasks)
                {
                    Guid itemID = item.Id;
                    //DraftTask drTask = getTask.GetById(item.Id.ToString());
                    var aa = projOnLineContext.LoadQuery(getTask.Where(p => p.Id == itemID));
                    projOnLineContext.ExecuteQuery();
                    DraftTask drTask = aa.First();
                    PropertyInfo[] properties = typeof(DraftTask).GetProperties();
                    foreach (PropertyInfo property in properties)
                    {
                        try
                        {
                            property.SetValue(drTask[property.ToString()], item[property.ToString()]);
                        }
                        catch (Exception ex) { }
                    }
                }
                qJob = projCheckedOut.Update();
                projCheckedOut.Publish(true);
                qJob = projOnLineContext.Projects.Update();
                jobState = projOnLineContext.WaitForQueue(qJob, timeoutSeconds);
                //projCreated = true;
                //Console.BackgroundColor = ConsoleColor.White;
                //Console.ForegroundColor = ConsoleColor.DarkGreen;
                //Console.WriteLine("task created successfully");
            }
            else
            {
                //Console.ForegroundColor = ConsoleColor.Yellow;
                //Console.WriteLine("\nThere is a problem in the queue. Timeout is {0} seconds.",
                //10);
                //Console.WriteLine("\tQueue JobState: {0}", jobState.ToString());
                //Console.ResetColor();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            ProjectUploadForm projUploadForm = new ProjectUploadForm();
            projUploadForm.projBackupForm = this;
            projUploadForm.Show();
            this.Hide();
        }



        private void cmb_Test_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public static int FieldIndex = 1;
        public static int TestIndex = 1;
        public static int ValueIndex = 1;
        public static int OperatorIndex = 1;

        public void cmb_Operator_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                ComboBox cmb = (ComboBox)sender;
                string SelectedValue = cmb.Name.Substring(cmb.Name.Length - 1, 1);
                int value = Convert.ToInt32(SelectedValue);
                string Svalue = cmb.SelectedValue.ToString().Trim();
                if (!string.IsNullOrEmpty(Svalue))
                {
                    if (value == FieldIndex - 1)
                    {
                        int Height = FieldIndex == 2 ? 15 : FieldIndex < 7 ? 15 + FieldIndex : 20;

                        ComboBox cmb_Field = new ComboBox();
                        pnl_CustomFilter.Controls.Add(cmb_Field);
                        cmb_Field.Name = "cmb_Field" + FieldIndex;
                        cmb_Field.Top = 20;
                        cmb_Field.Location = new Point(10, FieldIndex * Height);
                        cmb_Field.Size = new Size(114, 211);
                        cmb_Field.DataSource = GetFieldData();
                        cmb_Field.DisplayMember = "Key";
                        cmb_Field.ValueMember = "value";

                        ComboBox cmb_Test = new ComboBox();
                        pnl_CustomFilter.Controls.Add(cmb_Test);
                        cmb_Test.Name = "cmb_Test" + TestIndex;
                        cmb_Test.Top = 20;
                        cmb_Test.Location = new Point(130, TestIndex * Height);
                        cmb_Test.Size = new Size(100, 21);
                        cmb_Test.DataSource = GetTestData();
                        cmb_Test.DisplayMember = "Key";
                        cmb_Test.ValueMember = "value";


                        TextBox txt_Value = new TextBox();
                        pnl_CustomFilter.Controls.Add(txt_Value);
                        txt_Value.Name = "txt_Value" + ValueIndex;
                        txt_Value.Top = 20;
                        txt_Value.Location = new Point(240, ValueIndex * Height);
                        txt_Value.Size = new Size(98, 20);

                        ComboBox cmb_Operator = new ComboBox();
                        pnl_CustomFilter.Controls.Add(cmb_Operator);
                        cmb_Operator.Name = "cmb_Operator" + OperatorIndex;
                        cmb_Operator.Top = 20;
                        cmb_Operator.Location = new Point(345, OperatorIndex * Height);
                        cmb_Operator.Size = new Size(55, 21);
                        cmb_Operator.DataSource = GetOperatorData();
                        cmb_Operator.DisplayMember = "Key";
                        cmb_Operator.ValueMember = "value";
                        cmb_Operator.SelectedIndexChanged += new System.EventHandler(cmb_Operator_SelectedIndexChanged);
                        ++FieldIndex;
                        ++TestIndex;
                        ++ValueIndex;
                        ++OperatorIndex;

                    }
                }
            }
            catch
            { }
        }
        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (FieldIndex > 2)
                {

                    ComboBox cmd_Field = this.Controls.Find("cmb_Field" + (FieldIndex - 1).ToString(), true).FirstOrDefault() as ComboBox;
                    TextBox txt_Value = this.Controls.Find("txt_Value" + (FieldIndex - 1).ToString(), true).FirstOrDefault() as TextBox;
                    ComboBox cmd_Test = this.Controls.Find("cmb_Test" + (FieldIndex - 1).ToString(), true).FirstOrDefault() as ComboBox;
                    ComboBox cmd_op = this.Controls.Find("cmb_Operator" + (FieldIndex - 1).ToString(), true).FirstOrDefault() as ComboBox;
                    ComboBox cmd_op2 = this.Controls.Find("cmb_Operator" + (FieldIndex - 2).ToString(), true).FirstOrDefault() as ComboBox;
                    cmd_op2.SelectedValue = " ";
                    pnl_CustomFilter.Controls.Remove(cmd_Field);
                    pnl_CustomFilter.Controls.Remove(txt_Value);
                    pnl_CustomFilter.Controls.Remove(cmd_Test);
                    pnl_CustomFilter.Controls.Remove(cmd_op);
                    --FieldIndex;
                    --TestIndex;
                    --ValueIndex;
                    --OperatorIndex;
                }

            }
            catch
            { }

        }
        public List<TestData> GetOperatorData()
        {
            List<TestData> TestData_Obj = new List<TestData>();
            try
            {
                TestData_Obj.Add(new TestData { Key = " ", value = " " });
                TestData_Obj.Add(new TestData { Key = "And", value = "AND" });
                TestData_Obj.Add(new TestData { Key = "or", value = "OR" });
            }
            catch (Exception ex)
            { }
            return TestData_Obj;
        }
        public List<TestData> GetFieldData()
        {
            List<TestData> TestData_Obj = new List<TestData>();
            try
            {
                TestData_Obj.Add(new TestData { Key = " ", value = " " });
                TestData_Obj.Add(new TestData { Key = "% Complete", value = "PercentComplete" });
                TestData_Obj.Add(new TestData { Key = "Duration", value = "Duration" });
                TestData_Obj.Add(new TestData { Key = "Finish", value = "Finish" });
                TestData_Obj.Add(new TestData { Key = "Owner", value = "Owner" });
                TestData_Obj.Add(new TestData { Key = "Project Name", value = "ProjectName" });
                TestData_Obj.Add(new TestData { Key = "Start", value = "start" });
                //TestData_Obj.Add(new TestData { Key = "begins with", value = "begins with" });
                //TestData_Obj.Add(new TestData { Key = "contains", value = "contains" });
                // projContext.Load(projContext.Projects, c => c.IncludeWithDefaultProperties(pr => pr.IncludeCustomFields, pr => pr.IncludeCustomFields.CustomFields));
                //projContext.ExecuteQuery();               
                //foreach (PublishedProject pubProject in projContext.Projects)
                //{
                //    foreach (var cust in pubProject.IncludeCustomFields.FieldValues)
                //    {
                //        string CustomFieldName = pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList().Count == 0 ? string.Empty : pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList()[0].Name;
                //        string CustomFieldID = cust.Key.ToString();
                //        string CustomFieldValue = cust.Value.ToString();
                //        TestData_Obj.Add(new TestData
                //        {
                //            Key = CustomFieldName,
                //            value = CustomFieldName
                //        });
                //    }
                //    break;
                //}
                List<CustomFieldInfo> List_CustomFieldInfo = new List<CustomFieldInfo>();
                List_CustomFieldInfo = GetCustomFieldName();
                if (List_CustomFieldInfo != null && List_CustomFieldInfo.Count > 0)
                {
                    foreach (CustomFieldInfo item in List_CustomFieldInfo)
                    {
                        TestData_Obj.Add(new TestData
                        {
                            Key = item.Name,
                            value = item.Name
                        });
                    }
                }

            }
            catch (Exception ex)
            { }
            return TestData_Obj;
        }

        public List<CustomFieldInfo> GetCustomFieldName()
        {
            List<CustomFieldInfo> List_CustomFieldInfo = new List<CustomFieldInfo>();
            List<CustomFieldInfo> List_CustomFieldInfo_obj = new List<CustomFieldInfo>();
            try
            {
                foreach (PublishedProject pubProject in projContext.Projects)
                {
                    foreach (var cust in pubProject.IncludeCustomFields.FieldValues)
                    {
                        string CustomFieldName = pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList().Count == 0 ? string.Empty : pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList()[0].Name;
                        string FieldType = pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList().Count == 0 ? string.Empty : pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList()[0].FieldType.ToString();
                        string CustomFieldID = cust.Key.ToString();
                        string CustomFieldValue = cust.Value.ToString();
                        List_CustomFieldInfo.Add(new CustomFieldInfo
                        {
                            Name = CustomFieldName,
                            FieldType = FieldType
                        });
                    }
                }
                if (List_CustomFieldInfo != null && List_CustomFieldInfo.Count > 0)
                {
                    var List_CustomFieldInfo_obj1 = List_CustomFieldInfo.Select(x => new { x.Name, x.FieldType }).Distinct().ToList();
                    foreach (var item in List_CustomFieldInfo_obj1)
                    {
                        List_CustomFieldInfo_obj.Add(new CustomFieldInfo
                        {
                            Name = item.Name,
                            FieldType = item.FieldType
                        });
                    }
                }
            }
            catch
            { }
            return List_CustomFieldInfo_obj;
        }

        public List<TestData> GetTestData()
        {
            List<TestData> TestData_Obj = new List<TestData>();
            try
            {
                TestData_Obj.Add(new TestData { Key = " ", value = " " });
                TestData_Obj.Add(new TestData { Key = "equals", value = "=" });
                TestData_Obj.Add(new TestData { Key = "does not equal", value = "<>" });
                TestData_Obj.Add(new TestData { Key = "is less than", value = "<" });
                TestData_Obj.Add(new TestData { Key = "is less than or equal to", value = "<=" });
                TestData_Obj.Add(new TestData { Key = "is greater than", value = ">" });
                TestData_Obj.Add(new TestData { Key = "is greater than or equal to", value = ">=" });
                TestData_Obj.Add(new TestData { Key = "begins with", value = "begins with" });
                TestData_Obj.Add(new TestData { Key = "contains", value = "LIKE" });
            }
            catch (Exception ex)
            { }
            return TestData_Obj;
        }
        public void BindListWithProjectName()
        {
            List<ProjectInformation> ProjectInformation_Obj = new List<ProjectInformation>();
            List<ProjectInformation> ProjectInformation_Obj1 = new List<ProjectInformation>();
            try
            {
                DataTable table = new DataTable();
                table.Columns.Add("ProjectName", typeof(string));
                table.Columns.Add("start", typeof(DateTime));
                table.Columns.Add("Finish", typeof(DateTime));
                table.Columns.Add("Owner", typeof(string));
                table.Columns.Add("PercentComplete", typeof(int));
                table.Columns.Add("Duration", typeof(double));
                List<CustomFieldInfo> List_CustomFieldInfo = new List<CustomFieldInfo>();
                List_CustomFieldInfo = GetCustomFieldName();
                if (List_CustomFieldInfo != null && List_CustomFieldInfo.Count > 0)
                {
                    foreach (CustomFieldInfo item in List_CustomFieldInfo)
                    {
                        if (item.FieldType.Trim().ToUpper() == "NUMBER")
                        {
                            table.Columns.Add(item.Name.Replace('%', ' ').Trim(), typeof(double));
                        }
                        else if (item.FieldType.Trim().ToUpper() == "DATETIME")
                        {
                            table.Columns.Add(item.Name.Replace('%', ' ').Trim(), typeof(DateTime));
                        }
                        else
                        {
                            table.Columns.Add(item.Name.Replace('%', ' ').Trim(), typeof(string));
                        }
                    }
                }
                try
                {
                    foreach (PublishedProject pubProject in projContext.Projects)
                    {
                        DataRow dr = table.NewRow();
                        dr["ProjectName"] = string.IsNullOrEmpty(pubProject.Name) ? string.Empty : pubProject.Name;
                        dr["start"] = string.IsNullOrEmpty(pubProject.StartDate.ToShortDateString()) ? Convert.ToDateTime("01/01/0001") : Convert.ToDateTime(pubProject.StartDate.ToShortDateString());
                        dr["Finish"] = string.IsNullOrEmpty(pubProject.FinishDate.ToShortDateString()) ? Convert.ToDateTime("01/01/0001") : Convert.ToDateTime(pubProject.FinishDate.ToShortDateString());
                        dr["Owner"] = string.IsNullOrEmpty(pubProject.Owner.Title) ? string.Empty : pubProject.Owner.Title;
                        dr["PercentComplete"] = string.IsNullOrEmpty(pubProject.PercentComplete.ToString()) ? 0 : pubProject.PercentComplete;
                        dr["Duration"] = string.IsNullOrEmpty(pubProject.StartDate.ToShortDateString()) && string.IsNullOrEmpty(pubProject.FinishDate.ToShortDateString()) ? 0 : (pubProject.FinishDate - pubProject.StartDate).TotalDays;
                        foreach (var cust in pubProject.IncludeCustomFields.FieldValues)
                        {
                            string CustomFieldName = pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList().Count == 0 ? string.Empty : pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList()[0].Name;
                            string FieldType = pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList().Count == 0 ? string.Empty : pubProject.IncludeCustomFields.CustomFields.ToList().Where(pr => pr.InternalName == cust.Key).ToList()[0].FieldType.ToString();
                            string CustomFieldID = cust.Key.ToString();
                            string CustomFieldValue = cust.Value.ToString();
                            CustomFieldName = CustomFieldName.Replace('%', ' ').Trim();
                            if (FieldType.Trim().ToUpper() == "NUMBER")
                            {
                                dr[CustomFieldName] = string.IsNullOrEmpty(cust.Value.ToString()) ? 0 : Convert.ToDouble(cust.Value.ToString());
                            }
                            else if (FieldType.Trim().ToUpper() == "DATETIME")
                            {
                                dr[CustomFieldName] = string.IsNullOrEmpty(cust.Value.ToString()) ? Convert.ToDateTime("01/01/0001") : Convert.ToDateTime(cust.Value.ToString());
                            }
                            else
                            {
                                dr[CustomFieldName] = string.IsNullOrEmpty(cust.Value.ToString()) ? string.Empty : cust.Value.ToString();
                            }

                        }
                        table.Rows.Add(dr);
                    }
                }
                catch (Exception ex)
                {

                }

                string FilterString = string.Empty;
                string FilterStringNew = string.Empty;
                string FieldNameFirst = string.Empty;
                string FieldTestFirst = string.Empty;
                // int ControlIndex = 0;
                int rIndex = 0;
                int cIndex = 0;
                foreach (Control item in pnl_CustomFilter.Controls)
                {
                    if (rIndex == 4)
                    {
                        rIndex = 0;
                        ++cIndex;
                        FilterStringNew += FilterString;
                        FilterString = string.Empty;
                    }
                    string ControlName = item.Name.Remove(item.Name.Length - 1);
                    if (ControlName == "cmb_Field")
                    {
                        ComboBox cmd = this.Controls.Find(item.Name, true).FirstOrDefault() as ComboBox;
                        if (!string.IsNullOrEmpty(cmd.SelectedValue.ToString()))
                        {
                            FilterString += cmd.SelectedValue.ToString().Replace('%', ' ').Trim();
                            FieldNameFirst = cmd.SelectedValue.ToString();
                            ++rIndex;
                        }
                        else
                        {
                            break;
                        }
                    }
                    else if (ControlName == "cmb_Test")
                    {
                        ComboBox cmd = this.Controls.Find(item.Name, true).FirstOrDefault() as ComboBox;
                        if (!string.IsNullOrEmpty(cmd.SelectedValue.ToString()))
                        {
                            FilterString += " " + cmd.SelectedValue.ToString().Replace("begins with", "LIKE") + " ";
                            FieldTestFirst = cmd.SelectedValue.ToString();
                            ++rIndex;
                        }
                        else
                        {
                            break;
                        }
                    }
                    else if (ControlName == "txt_Value")
                    {

                        TextBox txt = this.Controls.Find(item.Name, true).FirstOrDefault() as TextBox;
                        double kk = 0;
                        string s = txt.Text;
                        bool result = double.TryParse(s, out kk); //i now = 108
                        if (!string.IsNullOrEmpty(txt.Text))
                        {
                            string FieldT = string.Empty;
                            if (FieldTestFirst == "begins with")
                            {
                                FilterString += "'" + txt.Text.Trim() + "%'";
                                ++rIndex;
                            }
                            else if (FieldTestFirst == "LIKE")
                            {
                                FilterString += "'%" + txt.Text.Trim() + "%'";
                                ++rIndex;
                            }
                            else if (!string.IsNullOrEmpty(FieldNameFirst))
                            {
                                if (FieldNameFirst != "ProjectName" && FieldNameFirst != "start" && FieldNameFirst != "Finish" && FieldNameFirst != "Owner" && FieldNameFirst != "PercentComplete" && FieldNameFirst != "Duration")
                                {
                                    FieldT = List_CustomFieldInfo.Find(x => x.Name == FieldNameFirst).FieldType;
                                    if (FieldT.ToUpper() == "TEXT")
                                    {
                                        FilterString += "'" + txt.Text.Trim() + "'";
                                        ++rIndex;
                                    }
                                    else
                                    {
                                        FilterString += " " + txt.Text.Trim() + " ";
                                        ++rIndex;
                                    }
                                }
                                else if (result)
                                {
                                    FilterString += " " + kk + " ";
                                    ++rIndex;
                                }
                                else
                                {
                                    FilterString += "'" + txt.Text.Trim() + "'";
                                    ++rIndex;
                                }
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    else if (ControlName == "cmb_Operator")
                    {
                        ComboBox cmd = this.Controls.Find(item.Name, true).FirstOrDefault() as ComboBox;
                        if (item.Text == "And")
                        {
                            FilterString += " " + cmd.SelectedValue + " ";
                            ++rIndex;
                        }
                        else if (item.Text == "or")
                        {
                            FilterString += " " + cmd.SelectedValue + " ";
                            ++rIndex;
                        }
                        else
                        {
                            break;
                        }
                    }
                }

                if (cIndex == 0 && rIndex == 3)
                {
                    FilterStringNew = FilterString;
                }
                else if (cIndex > 0 && rIndex == 3)
                {
                    FilterStringNew += FilterString;
                }
                else if (cIndex > 0 && rIndex < 3)
                {
                    char[] MyChar = { ' ', 'A', 'N', 'D', ' ' };
                    char[] MyChar1 = { ' ', 'O', 'R', ' ' };
                    FilterStringNew = FilterStringNew.TrimEnd(MyChar);
                    FilterStringNew = FilterStringNew.TrimEnd(MyChar1);
                }
                else if (cIndex == 0 && rIndex == 4)
                {
                    char[] MyChar = { ' ', 'A', 'N', 'D', ' ' };
                    char[] MyChar1 = { ' ', 'O', 'R', ' ' };
                    FilterStringNew = FilterStringNew.TrimEnd(MyChar);
                    FilterStringNew = FilterStringNew.TrimEnd(MyChar1);
                }

                DataRow[] dr_Filter = null;
                if (!string.IsNullOrEmpty(FilterStringNew))
                {
                    dr_Filter = table.Select(FilterStringNew);
                }
                chk_ProjectName.Items.Clear();
                if (dr_Filter != null && dr_Filter.Count() > 0)
                {
                    foreach (DataRow row in dr_Filter)
                    {
                        chk_ProjectName.Items.Add(Convert.ToString(row["ProjectName"]));
                    }
                }
            }
            catch
            {
                chk_ProjectName.Items.Clear();
            }

        }
        private void btn_ok_Click(object sender, EventArgs e)
        {
            try
            {
                BindListWithProjectName();
            }
            catch
            { }
        }
        private void btn_ClearFilter_Click(object sender, EventArgs e)
        {
            try
            {
                GetAllProjects();
                pnl_CustomFilter.Controls.Clear();
                GenerateDynamicControlFirstTime();
            }
            catch
            { }
        }
        public void GenerateDynamicControlFirstTime()
        {
            try
            {
                FieldIndex = 1;
                TestIndex = 1;
                ValueIndex = 1;
                OperatorIndex = 1;
                int Index = 0;
                for (Index = 1; Index < 4; Index++)
                {
                    FieldIndex = Index;
                    TestIndex = Index;
                    ValueIndex = Index;
                    OperatorIndex = Index;

                    int Height = FieldIndex == 1 ? 5 : FieldIndex == 2 ? 15 : FieldIndex < 7 ? 15 + FieldIndex : 20;

                    ComboBox cmb_Field = new ComboBox();
                    pnl_CustomFilter.Controls.Add(cmb_Field);
                    cmb_Field.Name = "cmb_Field" + FieldIndex;
                    cmb_Field.Top = 20;
                    cmb_Field.Location = new Point(3, FieldIndex * Height);
                    cmb_Field.Size = new Size(123, 211);
                    cmb_Field.DataSource = GetFieldData();
                    cmb_Field.DisplayMember = "Key";
                    cmb_Field.ValueMember = "value";

                    ComboBox cmb_Test = new ComboBox();
                    pnl_CustomFilter.Controls.Add(cmb_Test);
                    cmb_Test.Name = "cmb_Test" + TestIndex;
                    cmb_Test.Top = 20;
                    cmb_Test.Location = new Point(130, TestIndex * Height);
                    cmb_Test.Size = new Size(106, 21);
                    cmb_Test.DataSource = GetTestData();
                    cmb_Test.DisplayMember = "Key";
                    cmb_Test.ValueMember = "value";


                    TextBox txt_Value = new TextBox();
                    pnl_CustomFilter.Controls.Add(txt_Value);
                    txt_Value.Name = "txt_Value" + ValueIndex;
                    txt_Value.Top = 20;
                    txt_Value.Location = new Point(240, ValueIndex * Height);
                    txt_Value.Size = new Size(100, 20);

                    ComboBox cmb_Operator = new ComboBox();
                    pnl_CustomFilter.Controls.Add(cmb_Operator);
                    cmb_Operator.Name = "cmb_Operator" + OperatorIndex;
                    cmb_Operator.Top = 20;
                    cmb_Operator.Location = new Point(345, OperatorIndex * Height);
                    cmb_Operator.Size = new Size(55, 21);
                    cmb_Operator.DataSource = GetOperatorData();
                    cmb_Operator.DisplayMember = "Key";
                    cmb_Operator.ValueMember = "value";
                    //  cmb_Operator.SelectedIndexChanged += new System.EventHandler(cmb_Operator_SelectedIndexChanged);

                    if (OperatorIndex == 3)
                    {
                        cmb_Operator.Visible = false;
                    }
                }
                ++FieldIndex;
                ++TestIndex;
                ++ValueIndex;
                ++OperatorIndex;
            }
            catch
            { }
        }
        private void chk_SelectAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < chk_ProjectName.Items.Count; i++)
                {
                    if (chk_SelectAll.Checked)
                    {
                        chk_ProjectName.SetItemChecked(i, true);
                    }
                    else
                    {
                        chk_ProjectName.SetItemChecked(i, false);
                    }
                }
                int Count = 0;
                for (int i = 0; i < chk_ProjectName.Items.Count; i++)
                {
                    if (chk_ProjectName.GetItemChecked(i))
                    {
                        ++Count;
                    }
                }
                if (Count > 0)
                {
                    btnBackup.Enabled = true;
                }
                else
                {
                    btnBackup.Enabled = false;
                }
            }
            catch
            { }
        }
        public void GetAllProjects()
        {
            try
            {
                chk_ProjectName.Items.Clear();
                foreach (PublishedProject pubProject in projContext.Projects)
                {
                    chk_ProjectName.Items.Add(pubProject.Name.ToString());
                }
            }
            catch
            {

            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void chk_ProjectName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int Count = 0;
                List<string> ProjectName = new List<string>();
                for (int i = 0; i < chk_ProjectName.Items.Count; i++)
                {
                    if (chk_ProjectName.GetItemChecked(i))
                    {
                        ++Count;
                        ProjectName.Add(chk_ProjectName.Items[i].ToString());
                    }
                }
                if (Count > 0)
                {
                    if (Count == chk_ProjectName.Items.Count)
                    {
                        chk_SelectAll.Checked = true;
                    }
                    else
                    {
                        chk_SelectAll.Checked = false;

                        if (ProjectName.Count > 0)
                        {
                            for (int i = 0; i < chk_ProjectName.Items.Count; i++)
                            {
                                if (ProjectName.Contains(chk_ProjectName.Items[i].ToString()))
                                {
                                    chk_ProjectName.SetItemChecked(i, true);
                                }
                            }
                        }
                    }
                    btnBackup.Enabled = true;
                }
                else
                {
                    btnBackup.Enabled = false;
                }
            }
            catch
            { }
        }

    }

    public class ProjectInformation
    {
        public string ProjectName { get; set; }
        public DateTime start { get; set; }
        public DateTime Finish { get; set; }
        public int PercentComplete { get; set; }
        public double Duration { get; set; }
        public string Owner { get; set; }
    }

    public class ProjectInfo
    {
        public Guid ProjectUID { get; set; }
        public string ProjectName { get; set; }
        public List<ProjectCFData> ProjCFData { get; set; }
        public List<TaskCFData> TaskCFData { get; set; }
    }
    public class ProjectCFData
    {
        public string ProjectCustomFieldKeyName { get; set; }
        public string ProjectCustomFieldValue { get; set; }
    }
    public class TaskCFData
    {
        public string TaskID { get; set; }
        public string OutlinePosition { get; set; }
        public string OutlineLevel { get; set; }
        public string TaskCustomFieldKeyName { get; set; }
        public string TaskCustomFieldValue { get; set; }
    }
    public class TestData
    {
        public TestData()
        {
        }
        public string Key { get; set; }
        public string value { get; set; }
    }
    public class CustomFieldInfo
    {
        public CustomFieldInfo()
        {
            Name = string.Empty;
            FieldType = string.Empty;
        }
        public string Name { get; set; }
        public string FieldType { get; set; }
    }
}







