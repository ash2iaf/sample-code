﻿namespace MigrationUtility
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_SourceErrorMessage = new System.Windows.Forms.Label();
            this.btn_sourceLogin = new System.Windows.Forms.Button();
            this.txt_SourceURL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_SourceUPass = new System.Windows.Forms.TextBox();
            this.txt_SourceUName = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.lbl_UserName = new System.Windows.Forms.Label();
            this.backgroundWorkerLogin = new System.ComponentModel.BackgroundWorker();
            this.progressBarLogin = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_SourceErrorMessage);
            this.groupBox1.Controls.Add(this.btn_sourceLogin);
            this.groupBox1.Controls.Add(this.txt_SourceURL);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_SourceUPass);
            this.groupBox1.Controls.Add(this.txt_SourceUName);
            this.groupBox1.Controls.Add(this.Password);
            this.groupBox1.Controls.Add(this.lbl_UserName);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(149, 113);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(410, 197);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Source Login";
            // 
            // lbl_SourceErrorMessage
            // 
            this.lbl_SourceErrorMessage.AutoSize = true;
            this.lbl_SourceErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.lbl_SourceErrorMessage.Location = new System.Drawing.Point(134, 16);
            this.lbl_SourceErrorMessage.Name = "lbl_SourceErrorMessage";
            this.lbl_SourceErrorMessage.Size = new System.Drawing.Size(0, 13);
            this.lbl_SourceErrorMessage.TabIndex = 7;
            this.lbl_SourceErrorMessage.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_sourceLogin
            // 
            this.btn_sourceLogin.Location = new System.Drawing.Point(242, 154);
            this.btn_sourceLogin.Name = "btn_sourceLogin";
            this.btn_sourceLogin.Size = new System.Drawing.Size(75, 23);
            this.btn_sourceLogin.TabIndex = 6;
            this.btn_sourceLogin.Text = "Connect";
            this.btn_sourceLogin.UseVisualStyleBackColor = true;
            this.btn_sourceLogin.Click += new System.EventHandler(this.btn_sourceLogin_Click);
            // 
            // txt_SourceURL
            // 
            this.txt_SourceURL.Location = new System.Drawing.Point(132, 41);
            this.txt_SourceURL.Name = "txt_SourceURL";
            this.txt_SourceURL.Size = new System.Drawing.Size(185, 20);
            this.txt_SourceURL.TabIndex = 1;
            this.txt_SourceURL.Text = "https://projectonlinepremium.sharepoint.com/sites/pwa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "PWA URL";
            this.label1.UseMnemonic = false;
            // 
            // txt_SourceUPass
            // 
            this.txt_SourceUPass.Location = new System.Drawing.Point(132, 113);
            this.txt_SourceUPass.Name = "txt_SourceUPass";
            this.txt_SourceUPass.Size = new System.Drawing.Size(185, 20);
            this.txt_SourceUPass.TabIndex = 3;
            this.txt_SourceUPass.Text = "password321@";
            this.txt_SourceUPass.UseSystemPasswordChar = true;
            // 
            // txt_SourceUName
            // 
            this.txt_SourceUName.Location = new System.Drawing.Point(132, 77);
            this.txt_SourceUName.Name = "txt_SourceUName";
            this.txt_SourceUName.Size = new System.Drawing.Size(185, 20);
            this.txt_SourceUName.TabIndex = 2;
            this.txt_SourceUName.Text = "ProjectonlinePremium@ProjectonlinePremium.onmicrosoft.com";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(44, 113);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(61, 13);
            this.Password.TabIndex = 1;
            this.Password.Text = "Password";
            // 
            // lbl_UserName
            // 
            this.lbl_UserName.AutoSize = true;
            this.lbl_UserName.Location = new System.Drawing.Point(41, 77);
            this.lbl_UserName.Name = "lbl_UserName";
            this.lbl_UserName.Size = new System.Drawing.Size(69, 13);
            this.lbl_UserName.TabIndex = 0;
            this.lbl_UserName.Text = "User Name";
            this.lbl_UserName.UseMnemonic = false;
            // 
            // backgroundWorkerLogin
            // 
            this.backgroundWorkerLogin.WorkerReportsProgress = true;
            this.backgroundWorkerLogin.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerLogin_DoWork);
            // 
            // progressBarLogin
            // 
            this.progressBarLogin.Location = new System.Drawing.Point(149, 327);
            this.progressBarLogin.Name = "progressBarLogin";
            this.progressBarLogin.Size = new System.Drawing.Size(410, 23);
            this.progressBarLogin.Step = 600;
            this.progressBarLogin.TabIndex = 1;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(189, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "From";
            // 
            // comboBox1
            // 
            this.comboBox1.AllowDrop = true;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Project Online",
            "Project Server"});
            this.comboBox1.Location = new System.Drawing.Point(234, 49);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(372, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Project Online",
            "Project Server"});
            this.comboBox2.Location = new System.Drawing.Point(412, 52);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(149, 30);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(410, 66);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Migration ";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 362);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.progressBarLogin);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Label lbl_UserName;
        private System.Windows.Forms.TextBox txt_SourceURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_SourceUPass;
        private System.Windows.Forms.TextBox txt_SourceUName;
        private System.Windows.Forms.Button btn_sourceLogin;
        private System.ComponentModel.BackgroundWorker backgroundWorkerLogin;
        private System.Windows.Forms.ProgressBar progressBarLogin;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl_SourceErrorMessage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

