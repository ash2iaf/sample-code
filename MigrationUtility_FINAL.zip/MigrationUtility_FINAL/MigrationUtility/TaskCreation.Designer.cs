﻿namespace MigrationUtility
{
    partial class TaskCreation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chk_TaskSelect = new System.Windows.Forms.CheckedListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.progressBarLogin = new System.Windows.Forms.ProgressBar();
            this.lbl_SourceErrorMessage = new System.Windows.Forms.Label();
            this.btn_DestLogin = new System.Windows.Forms.Button();
            this.txt_DestURL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_DestUPass = new System.Windows.Forms.TextBox();
            this.txt_DestUName = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.lbl_UserName = new System.Windows.Forms.Label();
            this.timer_login = new System.Windows.Forms.Timer(this.components);
            this.backgroundWorkerLogin = new System.ComponentModel.BackgroundWorker();
            this.btn_Start = new System.Windows.Forms.Button();
            this.progressBarCreateTask = new System.Windows.Forms.ProgressBar();
            this.lbl_loginfo = new System.Windows.Forms.Label();
            this.backgroundWorkerCreateTask = new System.ComponentModel.BackgroundWorker();
            this.lbl_log = new System.Windows.Forms.Label();
            this.timerLog = new System.Windows.Forms.Timer(this.components);
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // chk_TaskSelect
            // 
            this.chk_TaskSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_TaskSelect.FormattingEnabled = true;
            this.chk_TaskSelect.Items.AddRange(new object[] {
            "Projects",
            "Tasks",
            "Custom Fields Creation",
            "Custom Fields Update",
            "Resource"});
            this.chk_TaskSelect.Location = new System.Drawing.Point(101, 50);
            this.chk_TaskSelect.Name = "chk_TaskSelect";
            this.chk_TaskSelect.Size = new System.Drawing.Size(247, 169);
            this.chk_TaskSelect.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(72, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 210);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Task";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.progressBarLogin);
            this.groupBox2.Controls.Add(this.lbl_SourceErrorMessage);
            this.groupBox2.Controls.Add(this.btn_DestLogin);
            this.groupBox2.Controls.Add(this.txt_DestURL);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txt_DestUPass);
            this.groupBox2.Controls.Add(this.txt_DestUName);
            this.groupBox2.Controls.Add(this.Password);
            this.groupBox2.Controls.Add(this.lbl_UserName);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(407, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(410, 210);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Destination Login";
            // 
            // progressBarLogin
            // 
            this.progressBarLogin.Location = new System.Drawing.Point(121, 188);
            this.progressBarLogin.Name = "progressBarLogin";
            this.progressBarLogin.Size = new System.Drawing.Size(196, 16);
            this.progressBarLogin.Step = 600;
            this.progressBarLogin.TabIndex = 8;
            // 
            // lbl_SourceErrorMessage
            // 
            this.lbl_SourceErrorMessage.AutoSize = true;
            this.lbl_SourceErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.lbl_SourceErrorMessage.Location = new System.Drawing.Point(139, 144);
            this.lbl_SourceErrorMessage.Name = "lbl_SourceErrorMessage";
            this.lbl_SourceErrorMessage.Size = new System.Drawing.Size(0, 13);
            this.lbl_SourceErrorMessage.TabIndex = 7;
            this.lbl_SourceErrorMessage.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_DestLogin
            // 
            this.btn_DestLogin.Location = new System.Drawing.Point(242, 144);
            this.btn_DestLogin.Name = "btn_DestLogin";
            this.btn_DestLogin.Size = new System.Drawing.Size(75, 23);
            this.btn_DestLogin.TabIndex = 6;
            this.btn_DestLogin.Text = "Connect";
            this.btn_DestLogin.UseVisualStyleBackColor = true;
            this.btn_DestLogin.Click += new System.EventHandler(this.btn_DestLogin_Click);
            // 
            // txt_DestURL
            // 
            this.txt_DestURL.Location = new System.Drawing.Point(132, 41);
            this.txt_DestURL.Name = "txt_DestURL";
            this.txt_DestURL.Size = new System.Drawing.Size(185, 20);
            this.txt_DestURL.TabIndex = 1;
            this.txt_DestURL.Text = "https://projectonlinepremium.sharepoint.com/sites/pwa2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "PWA URL";
            this.label1.UseMnemonic = false;
            // 
            // txt_DestUPass
            // 
            this.txt_DestUPass.Location = new System.Drawing.Point(132, 113);
            this.txt_DestUPass.Name = "txt_DestUPass";
            this.txt_DestUPass.Size = new System.Drawing.Size(185, 20);
            this.txt_DestUPass.TabIndex = 3;
            this.txt_DestUPass.Text = "password321@";
            this.txt_DestUPass.UseSystemPasswordChar = true;
            // 
            // txt_DestUName
            // 
            this.txt_DestUName.Location = new System.Drawing.Point(132, 77);
            this.txt_DestUName.Name = "txt_DestUName";
            this.txt_DestUName.Size = new System.Drawing.Size(185, 20);
            this.txt_DestUName.TabIndex = 2;
            this.txt_DestUName.Text = "ProjectonlinePremium@ProjectonlinePremium.onmicrosoft.com";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(44, 113);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(61, 13);
            this.Password.TabIndex = 1;
            this.Password.Text = "Password";
            // 
            // lbl_UserName
            // 
            this.lbl_UserName.AutoSize = true;
            this.lbl_UserName.Location = new System.Drawing.Point(41, 77);
            this.lbl_UserName.Name = "lbl_UserName";
            this.lbl_UserName.Size = new System.Drawing.Size(69, 13);
            this.lbl_UserName.TabIndex = 0;
            this.lbl_UserName.Text = "User Name";
            this.lbl_UserName.UseMnemonic = false;
            // 
            // timer_login
            // 
            this.timer_login.Tick += new System.EventHandler(this.timerLogin_Tick);
            // 
            // backgroundWorkerLogin
            // 
            this.backgroundWorkerLogin.WorkerReportsProgress = true;
            this.backgroundWorkerLogin.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerLogin_DoWork);
            // 
            // btn_Start
            // 
            this.btn_Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Start.Location = new System.Drawing.Point(335, 258);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(120, 23);
            this.btn_Start.TabIndex = 4;
            this.btn_Start.Text = "Start Now";
            this.btn_Start.UseVisualStyleBackColor = true;
            this.btn_Start.Visible = false;
            this.btn_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // progressBarCreateTask
            // 
            this.progressBarCreateTask.Location = new System.Drawing.Point(72, 347);
            this.progressBarCreateTask.Name = "progressBarCreateTask";
            this.progressBarCreateTask.Size = new System.Drawing.Size(745, 23);
            this.progressBarCreateTask.Step = 600;
            this.progressBarCreateTask.TabIndex = 5;
            this.progressBarCreateTask.Visible = false;
            // 
            // lbl_loginfo
            // 
            this.lbl_loginfo.AutoSize = true;
            this.lbl_loginfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginfo.Location = new System.Drawing.Point(105, 309);
            this.lbl_loginfo.Name = "lbl_loginfo";
            this.lbl_loginfo.Size = new System.Drawing.Size(0, 13);
            this.lbl_loginfo.TabIndex = 6;
            // 
            // backgroundWorkerCreateTask
            // 
            this.backgroundWorkerCreateTask.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerCreateTask_DoWork);
            // 
            // lbl_log
            // 
            this.lbl_log.AutoSize = true;
            this.lbl_log.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_log.Location = new System.Drawing.Point(63, 309);
            this.lbl_log.Name = "lbl_log";
            this.lbl_log.Size = new System.Drawing.Size(36, 13);
            this.lbl_log.TabIndex = 7;
            this.lbl_log.Text = "Log: ";
            this.lbl_log.Visible = false;
            // 
            // timerLog
            // 
            this.timerLog.Interval = 1500;
            this.timerLog.Tick += new System.EventHandler(this.timerLog_Tick);
            // 
            // TaskCreation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 382);
            this.Controls.Add(this.lbl_log);
            this.Controls.Add(this.lbl_loginfo);
            this.Controls.Add(this.progressBarCreateTask);
            this.Controls.Add(this.btn_Start);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.chk_TaskSelect);
            this.Controls.Add(this.groupBox1);
            this.Name = "TaskCreation";
            this.Text = "SelectTasks";
            this.Load += new System.EventHandler(this.SelectTasks_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckedListBox chk_TaskSelect;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbl_SourceErrorMessage;
        private System.Windows.Forms.Button btn_DestLogin;
        private System.Windows.Forms.TextBox txt_DestURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_DestUPass;
        private System.Windows.Forms.TextBox txt_DestUName;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Label lbl_UserName;
        private System.Windows.Forms.Timer timer_login;
        private System.ComponentModel.BackgroundWorker backgroundWorkerLogin;
        private System.Windows.Forms.ProgressBar progressBarLogin;
        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.ProgressBar progressBarCreateTask;
        private System.ComponentModel.BackgroundWorker backgroundWorkerCreateTask;
        private System.Windows.Forms.Timer timerLog;
        public System.Windows.Forms.Label lbl_loginfo;
        private System.Windows.Forms.Label lbl_log;
    }
}